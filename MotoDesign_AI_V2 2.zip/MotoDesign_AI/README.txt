MotoDesign AI V2 — prototype

Fonctions: catalogue de démonstration, panier local (non persistant), studio de prompt, copie du prompt et résumé indicatif du panier.
Limites: aucune génération image IA connectée, aucun paiement, aucun formulaire de contact/envoi, pas de stockage/serveur. Les tarifs sont fictifs.

Publication gratuite possible via GitHub Pages:
1) Créer un dépôt GitHub et y déposer index.html.
2) Settings > Pages > Deploy from branch > main > /(root).
3) Attendre la publication.

Avant d'ouvrir une boutique réelle: confirmer droits/licences, prix, taxes, conditions, confidentialité, paiement, livraison et restrictions d'âge des fournisseurs. Ne pas utiliser de logos/éléments protégés sans autorisation.
